TalkEasy frontend (Vite + React). Set VITE_API_BASE to your backend URL before deploy.
